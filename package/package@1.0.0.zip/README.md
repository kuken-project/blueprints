# Kuken Blueprints

A curated collection of application blueprints for [Kuken](https://kuken.io), written in [Pkl](https://pkl-lang.org) configuration language. Blueprints define standardized configurations for deploying containerized applications with user-friendly input interfaces, environment variables, and runtime settings.

## What are Blueprints?

Blueprints are declarative configuration templates that describe how to deploy and configure applications in Kuken. Each blueprint defines:

- **User Inputs**: Configuration options presented to users (ports, passwords, versions, etc.)
- **Docker Configuration**: Container images and runtime settings
- **Environment Variables**: Dynamic configuration passed to containers
- **Instance Settings**: Startup commands and runtime behavior
- **Metadata**: Application name, version, documentation links, and visual assets

Blueprints enable users to deploy complex applications without writing configuration files manually, while maintaining type safety and validation through Pkl's schema system.

## Project Structure

```
kuken-blueprints/
├── blueprints/
│   ├── games/              # Game server blueprints
│   │   ├── minecraft/      # Minecraft Java Edition
│   │   └── hytale/         # Hytale (upcoming game)
│   └── icons/              # Application icons and visual assets
├── reference/
│   └── v1/
│       └── Reference.pkl   # Blueprint schema definition
├── processor/              # Blueprint processing utilities
├── package/                # Packaged blueprint releases
├── PklProject              # Pkl project configuration
└── CONTRIBUTING.md         # Contribution guidelines
```

## Technology Stack

### Pkl Configuration Language

This project uses [Pkl](https://pkl-lang.org) (pronounced "Pickle"), Apple's configuration language that provides:

- **Type Safety**: Catch configuration errors before deployment
- **Schema Validation**: Enforce structure and constraints
- **Dynamic Configuration**: Reference inputs and runtime values
- **Documentation as Code**: Inline documentation for inputs and settings
- **Package Management**: Versioned, shareable configuration modules

### Why Pkl?

Unlike YAML or JSON, Pkl offers:
- Strong typing and validation at configuration time
- Programmatic configuration with functions and logic
- Inheritance and composition through modules
- Built-in documentation generation
- IDE support with autocomplete and type checking

## Available Blueprints

### Game Servers

- **Minecraft: Java Edition** (`blueprints/games/minecraft/minecraft-vanilla.pkl`)
  - Docker Image: `itzg/minecraft-server`
  - Configurable Java version (8, 11, 17, 21, 25)
  - Version selection (Latest, Snapshot, or specific versions)
  - [itzg/minecraft-server Documentation](https://github.com/itzg/docker-minecraft-server)

- **Hytale** (`blueprints/games/hytale/hytale.pkl`)
  - Docker Image: `ghcr.io/pterodactyl/games:hytale`
  - Authentication modes
  - Plugin system with Source Query support
  - AOT cache optimization
  - Custom startup configuration

## Blueprint Anatomy

A typical Kuken blueprint contains:

```pkl
module io.kuken.category.ApplicationName

amends "file://reference/v1/Reference.pkl"

// Metadata
name = "Application Name"
version = "1.0.0"
url = "https://official-site.com"
description = "Brief description"

// Visual assets
assets {
  icon = "https://kuken.io/blueprints/icons/app-icon.png"
}

// User inputs
local ServerPort = new PortInput {
  name = "server-port"
  label = "Server Port"
  default = 25565
}

// Docker configuration
build {
  docker {
    image = "official/image:tag"
  }

  env = new Mapping {
    ["CONFIG_VAR"] = ServerPort
    ["STATIC_VAR"] = "value"
  }
}

// Runtime settings
instance {
  startup = "java -jar server.jar"
  command = ssh("console-command \(refs.instance.command)")
}

// Expose inputs to users
inputs {
  ServerPort
}
```

## Getting Started

### Prerequisites

- **Pkl CLI** (version 0.30.2 or higher)
  - Download: [pkl-lang.org](https://pkl-lang.org/main/current/pkl-cli/index.html)
  - Install: `brew install pkl` (macOS) or download binaries

### Evaluating a Blueprint

```bash
# Validate blueprint syntax
pkl eval blueprints/games/minecraft/minecraft-vanilla.pkl

# Test blueprint with custom values
pkl eval -p game-version=1.20.4 blueprints/games/minecraft/minecraft-vanilla.pkl

# Generate documentation
pkl eval --format yaml blueprints/games/minecraft/minecraft-vanilla.pkl
```

### Using Blueprints in Kuken

Blueprints are automatically loaded from the Kuken package registry. Users select blueprints through the Kuken interface, configure inputs, and deploy instances without touching configuration files.

## Contributing

We welcome contributions of new blueprints and improvements to existing ones. See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines on:

- Blueprint naming conventions
- Documentation style
- Input design best practices
- Docker image selection
- Testing and validation
- Submission process

### Quick Contribution Checklist

- [ ] Blueprint follows the Reference schema
- [ ] Input IDs use kebab-case
- [ ] Input labels are user-friendly
- [ ] Environment variables match application documentation
- [ ] Docker image is official or well-maintained
- [ ] Documentation is concise and helpful
- [ ] Blueprint validates with `pkl eval`

## Package Information

- **Package Name**: `blueprints`
- **Base URI**: `package://raw.githubusercontent.com/devnatan/kuken/refs/heads/main/blueprints/package`
- **Version**: `1.0.0`
- **License**: Apache-2.0
- **Website**: [kuken.io](https://kuken.io)
- **Documentation**: [docs.kuken.io](https://docs.kuken.io)

## Resources

- **Kuken Website**: [https://kuken.io](https://kuken.io)
- **Documentation**: [https://docs.kuken.io](https://docs.kuken.io)
- **Pkl Language**: [https://pkl-lang.org](https://pkl-lang.org)
- **Blueprint Reference**: [reference/v1/Reference.pkl](reference/v1/Reference.pkl)
- **GitHub Repository**: [https://github.com/devnatan/kuken](https://github.com/devnatan/kuken)

## Blueprint Categories

Blueprints are organized by application category:

- `games/` - Game servers (Minecraft, Hytale, etc.)
- `databases/` - Database systems (PostgreSQL, MySQL, Redis, etc.)
- `web-servers/` - Web servers (NGINX, Apache, Caddy, etc.)
- `monitoring/` - Monitoring tools (Prometheus, Grafana, etc.)
- `messaging/` - Message brokers (RabbitMQ, Kafka, etc.)
- `development/` - Development tools (GitLab, Jenkins, etc.)
- `media/` - Media servers (Plex, Jellyfin, etc.)

## License

This project is licensed under the Apache License 2.0. See the LICENSE file for details.

## Support

- **Issues**: Report bugs or request features on GitHub Issues
- **Discussions**: Join community discussions for blueprint ideas
- **Documentation**: Comprehensive guides at [docs.kuken.io](https://docs.kuken.io)

---

Built with [Pkl](https://pkl-lang.org) for [Kuken](https://kuken.io)
